gsap.from("#img1",{
    delay:0.5,
    opacity:0,
    duration:1,
    y:70
})
gsap.from("#img2",{
    delay:0.5,
    opacity:0,
    duration:1,
    x:70
})
gsap.from("#img3",{
    delay:0.5,
    opacity:0,
    duration:1,
    y:-70
})
gsap.from("main h1",{
    delay:0.5,
    opacity:0,
    duration:1,
    y:70
})




